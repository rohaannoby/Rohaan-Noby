# rohaan-noby-portfolio

Personal portfolio for Rohaan Noby, aimed at sales and business development roles in Ireland.
Content comes from the CV and LinkedIn profile only.

## Technology stack

- Next.js 14 (App Router), React 18
- Tailwind CSS 3 with CSS-variable colours for light and dark mode
- Google Fonts via `next/font` (Bricolage Grotesque, Public Sans)

No API keys or environment variables are needed.

## Run locally

Requires Node.js 18.17 or newer and an internet connection (for the fonts on first run).

```bash
npm install
npm run dev
```

Open http://localhost:3000.

## Customize

- **Text and links:** edit `data/content.js`. Every section reads from it.
- **Phone number:** set `profile.phone` in `data/content.js` to show it in Contact (empty by default).
- **Photo:** replace `public/rohaan-noby.jpg` (shown in About).
- **CV file:** replace `public/Rohaan_Noby_CV.docx` (or change `profile.cv`). A PDF works too.
- **Colours:** edit the CSS variables at the top of `app/globals.css`.
- **Section order:** edit `app/page.jsx`.

## Deploy

Push to GitHub and import the repository into Vercel. No settings needed.
