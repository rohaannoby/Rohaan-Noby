import Section from "./Section";
import { about, profile } from "@/data/content";

export default function About() {
  return (
    <Section id="about" title="About">
      <div className="grid gap-10 lg:grid-cols-[1fr_280px] lg:items-start">
        <div className="max-w-[65ch] space-y-4 text-lg leading-relaxed">
          {about.map((p) => <p key={p}>{p}</p>)}
        </div>
        {/* Replace public/rohaan-noby.jpg to change the photo */}
        <img
          src="/rohaan-noby.jpg"
          alt={`Portrait of ${profile.name}`}
          width={280}
          height={373}
          className="w-full max-w-[280px] rounded-sm border border-line object-cover"
        />
      </div>
    </Section>
  );
}
