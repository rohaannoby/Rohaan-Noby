import Section from "./Section";
import { about } from "@/data/content";

export default function About() {
  return (
    <Section id="about" title="About">
      <div className="max-w-[65ch] space-y-4 text-lg leading-relaxed">
        {about.map((p) => <p key={p}>{p}</p>)}
      </div>
    </Section>
  );
}
