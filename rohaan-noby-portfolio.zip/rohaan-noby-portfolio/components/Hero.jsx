import { profile, salesCycle } from "@/data/content";

export default function Hero() {
  return (
    <section id="top" className="mx-auto grid max-w-6xl items-center gap-12 px-5 py-14 md:grid-cols-[1.25fr_1fr] md:py-24">
      <div>
        <p className="text-muted">{profile.title}, {profile.location}</p>
        <h1 className="mt-4 max-w-[22ch] font-display text-4xl font-semibold leading-[1.05] tracking-tight sm:text-5xl md:text-6xl">
          {profile.headline}
        </h1>
        <p className="mt-6 max-w-[56ch] text-lg leading-relaxed text-muted">{profile.intro}</p>
        <div className="mt-8 flex flex-wrap gap-3">
          <a href={`mailto:${profile.email}`} className="rounded-full bg-accent px-6 py-3 font-medium text-white transition-opacity hover:opacity-90">
            Email me
          </a>
          <a href={profile.cv} download className="rounded-full border border-line px-6 py-3 font-medium transition-colors hover:border-accent">
            Download CV
          </a>
        </div>
      </div>

      {/* Order slip: the sales cycle I ran myself at Gadgets For You */}
      <aside aria-label={`How ${salesCycle.name} sold`} className="rounded-sm border border-dashed border-line bg-surface p-6 shadow-sm">
        <p className="font-display text-xl font-semibold">{salesCycle.name}</p>
        <p className="mt-1 text-sm text-muted">The sales cycle I ran end to end</p>
        <ol className="mt-5 space-y-3">
          {salesCycle.steps.map((s, i) => (
            <li key={s} className="slip-line flex gap-3" style={{ animationDelay: `${0.25 + i * 0.3}s` }}>
              <span className="font-display font-semibold text-accent">{i + 1}</span>
              <span>{s}</span>
            </li>
          ))}
        </ol>
        <p className="slip-line mt-6 border-t border-dashed border-line pt-4 font-medium" style={{ animationDelay: "1.6s" }}>
          {salesCycle.result}
        </p>
      </aside>
    </section>
  );
}
