import Section from "./Section";
import { profile } from "@/data/content";

export default function Contact() {
  return (
    <Section id="contact" title="Contact">
      <p className="max-w-[40ch] font-display text-3xl font-semibold leading-tight">
        Hiring for sales or business development in Ireland? Let's talk.
      </p>
      <div className="mt-8 flex flex-wrap gap-3">
        <a href={`mailto:${profile.email}`} className="rounded-full bg-accent px-6 py-3 font-medium text-white transition-opacity hover:opacity-90">{profile.email}</a>
        <a href={profile.linkedin} target="_blank" rel="noopener noreferrer" className="rounded-full border border-line px-6 py-3 font-medium transition-colors hover:border-accent">LinkedIn</a>
        {profile.phone && (
          <a href={`tel:${profile.phone.replace(/\s/g, "")}`} className="rounded-full border border-line px-6 py-3 font-medium transition-colors hover:border-accent">{profile.phone}</a>
        )}
      </div>
      <p className="mt-16 text-sm text-muted">{profile.name}, {profile.location}</p>
    </Section>
  );
}
