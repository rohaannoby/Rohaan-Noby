import Section from "./Section";
import { work } from "@/data/content";

export default function Work() {
  return (
    <Section id="work" title="Selected work">
      <div className="space-y-6">
        {work.map((w) => (
          <article key={w.name} className="rounded-sm border border-line bg-surface p-6 transition-colors hover:border-accent md:p-8">
            <h3 className="font-display text-xl font-semibold md:text-2xl">{w.name}</h3>
            <p className="mt-1 text-sm text-muted">{w.kind}</p>
            <p className="mt-4 leading-relaxed">{w.summary}</p>
            <dl className="mt-5 grid gap-4 text-sm sm:grid-cols-2">
              <div>
                <dt className="font-semibold">What I did</dt>
                <dd className="mt-1 leading-relaxed text-muted">{w.contribution}</dd>
              </div>
              <div>
                <dt className="font-semibold">Result</dt>
                <dd className="mt-1 leading-relaxed text-muted">{w.outcome}</dd>
              </div>
            </dl>
            <ul className="mt-5 flex flex-wrap gap-2">
              {w.tags.map((t) => (
                <li key={t} className="rounded-full border border-line px-3 py-1 text-xs text-muted">{t}</li>
              ))}
            </ul>
          </article>
        ))}
      </div>
    </Section>
  );
}
