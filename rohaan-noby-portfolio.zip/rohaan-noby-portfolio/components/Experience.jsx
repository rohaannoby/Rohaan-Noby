import Section from "./Section";
import { experience } from "@/data/content";

export default function Experience() {
  return (
    <Section id="experience" title="Experience">
      <ol className="space-y-10 border-l border-line pl-6">
        {experience.map((e) => (
          <li key={e.role + e.org} className="relative">
            <span className="absolute -left-[29px] top-2 h-2.5 w-2.5 rounded-full bg-accent" aria-hidden="true" />
            <h3 className="font-display text-xl font-semibold">{e.role}</h3>
            <p className="text-sm text-muted">{e.org}, {e.period}</p>
            <ul className="mt-3 max-w-[65ch] list-disc space-y-2 pl-5 leading-relaxed marker:text-accent">
              {e.points.map((p) => <li key={p}>{p}</li>)}
            </ul>
          </li>
        ))}
      </ol>
    </Section>
  );
}
