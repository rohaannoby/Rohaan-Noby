import Section from "./Section";
import { education, certifications } from "@/data/content";

export default function Education() {
  return (
    <Section id="education" title="Education and certifications">
      <div className="space-y-6">
        {education.map((e) => (
          <div key={e.title}>
            <h3 className="font-display text-xl font-semibold">{e.title}</h3>
            <p className="text-sm text-muted">{e.org}</p>
            <p className="mt-2 max-w-[65ch] leading-relaxed">{e.detail}</p>
          </div>
        ))}
        <ul className="grid gap-2 border-t border-line pt-6 sm:grid-cols-2">
          {certifications.map((c) => (
            <li key={c} className="leading-relaxed text-muted">{c}</li>
          ))}
        </ul>
      </div>
    </Section>
  );
}
