import ThemeToggle from "./ThemeToggle";
import { profile } from "@/data/content";

const links = [
  ["Work", "#work"],
  ["About", "#about"],
  ["Experience", "#experience"],
  ["Skills", "#skills"],
  ["Contact", "#contact"],
];

export default function Nav() {
  return (
    <header className="sticky top-0 z-20 border-b border-line bg-bg/90 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-5 py-3">
        <a href="#top" className="font-display text-lg font-semibold">{profile.name}</a>
        <nav aria-label="Main" className="hidden gap-6 text-sm text-muted md:flex">
          {links.map(([label, href]) => (
            <a key={href} href={href} className="transition-colors hover:text-ink">{label}</a>
          ))}
        </nav>
        <div className="flex items-center gap-3">
          <a href="#contact" className="rounded-full bg-accent px-4 py-1.5 text-sm font-medium text-white transition-opacity hover:opacity-90 md:hidden">Contact</a>
          <ThemeToggle />
        </div>
      </div>
    </header>
  );
}
