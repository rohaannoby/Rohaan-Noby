// All portfolio content lives here. Edit this file to update the site.
// Every item comes from the CV / LinkedIn profile.

export const profile = {
  name: "Rohaan Noby",
  title: "Sales & Business Development",
  headline: "I built an e-commerce business to €9,000 in annual net sales. Now I want to grow yours.",
  intro:
    "MSc Management (Strategy) graduate from Dublin City University, looking for a sales or business development role in Ireland.",
  location: "Dublin, Ireland",
  email: "rohaannoby@gmail.com",
  phone: "", // optional: add e.g. "+353 ..." to show it in Contact
  linkedin: "https://www.linkedin.com/in/rohaan-noby-74ba00205/",
  cv: "/Rohaan_Noby_CV.docx",
};

export const about = [
  "I started Gadgets For You and ran it on my own: finding customers, agreeing prices, closing sales and looking after buyers afterwards. It grew to €9,000 in annual net sales, at roughly 100% growth year on year.",
  "Alongside it I completed a BBA in Aviation, and in 2026 an MSc in Management (Strategy) at Dublin City University, covering marketing strategy, digital transformation and sustainable value.",
  "Today I work in customer relations and sales at IKEA Dublin, helping customers choose products and resolving issues on the shop floor.",
];

export const salesCycle = {
  name: "Gadgets For You",
  steps: [
    "Prospecting and lead generation",
    "Pricing negotiation",
    "Closing the sale",
    "Long-term customer relationships",
  ],
  result: "€9,000 annual net sales, ~100% year-on-year growth",
};

export const work = [
  {
    name: "Gadgets For You",
    kind: "Founder, e-commerce business (2015 – 2023)",
    summary:
      "An online business selling customisable phone covers and skins and electronic gadgets, with web design and social media services for small business clients.",
    contribution:
      "Ran it independently from prospecting to after-sales: lead generation, pricing negotiations, closing sales and customer retention, supported by targeted digital marketing.",
    outcome: "€9,000 in annual net sales with approximately 100% year-on-year growth.",
    tags: ["Lead generation", "Negotiation", "Digital marketing", "Customer retention", "Web design"],
  },
  {
    name: "How Retail Traders Manage Risk During Economic Recessions",
    kind: "MSc dissertation, Dublin City University (2026)",
    summary:
      "Research project on how retail traders manage risk when the economy contracts.",
    contribution:
      "Carried out the research and analysis independently as the final project of the MSc in Management (Strategy).",
    outcome: "Completed with Second Class Honours, Grade II overall.",
    tags: ["Market research", "Analysis", "Financial markets", "Strategy"],
  },
  {
    name: "Customer Relations & Sales, IKEA Ballymun",
    kind: "Co-worker (January 2026 – present)",
    summary:
      "Sales support and customer service in a high-volume retail store, on the shop floor and at customer service points.",
    contribution:
      "Advise customers on products and cross-sell, handle queries, returns and after-sales support, support seasonal promotions, and prepare the daily floor plan for shift staffing.",
    outcome: "Keeps customers satisfied and coming back during peak trading hours.",
    tags: ["Cross-selling", "After-sales", "Promotions", "Team coordination"],
  },
];

export const experience = [
  {
    role: "Customer Relations & Sales Co-worker",
    org: "IKEA, Dublin – Ballymun",
    period: "Jan 2026 – Present",
    points: [
      "Help customers choose products and make purchase decisions, including cross-selling, in a high-volume store.",
      "Prepare the daily floor plan for shift staffing and coordinate coverage across departments at peak times.",
      "Resolve queries, returns and after-sales issues to maintain customer satisfaction and repeat custom.",
      "Support in-store commercial activity and seasonal promotions.",
    ],
  },
  {
    role: "Baggage Hall Agent",
    org: "Sky Handling Partner, Dublin Airport",
    period: "Apr 2025 – Nov 2025",
    points: [
      "Delivered customer-facing service under time pressure, coordinating with airside teams to support on-time flights.",
      "Worked across teams to resolve operational issues quickly.",
    ],
  },
  {
    role: "Founder",
    org: "Gadgets For You (e-commerce)",
    period: "2015 – 2023",
    points: [
      "Founded and independently ran an online store for customisable phone covers and gadgets, plus web design and social media services for small businesses.",
      "Grew the business to €9,000 annual net sales at about 100% year-on-year growth.",
      "Owned the full sales process: prospecting, pricing negotiations, closing and long-term relationships.",
    ],
  },
];

export const skills = [
  { group: "Selling", items: ["Business development", "Sales and negotiation", "Lead generation", "Client relationship management"] },
  { group: "Marketing and research", items: ["Digital marketing (SEO, SEM, social)", "Market research and analysis"] },
  { group: "Strategy and finance", items: ["Business strategy", "Financial planning and budgeting", "Sustainable business practices"] },
  { group: "Working with people", items: ["Team leadership", "Stakeholder communication"] },
  { group: "Languages", items: ["English", "Hindi", "Malayalam", "Tamil"] },
];

export const education = [
  {
    title: "MSc in Management (Strategy)",
    org: "Dublin City University, Ireland",
    detail: "Graduated 2026, Second Class Honours, Grade II. Coursework: Marketing Strategy, Global Management, Digital Transformation, Building Sustainable Value.",
  },
  {
    title: "Bachelor of Business Administration in Aviation",
    org: "Jain University, India",
    detail: "Graduated November 2023.",
  },
];

export const certifications = [
  "NISM Certified, Financial Markets",
  "Certificate of Achievement, Business Ethics, Dublin City University",
  "Valid Airport AIC (Airside Identification Card)",
  "District Powerlifting Champion",
  "IELTS Overall 7.5 (Listening 7.5, Reading 7.0, Writing 7.0, Speaking 7.5)",
];
